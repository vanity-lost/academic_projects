package src;

public class ServiceRestException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ServiceRestException(String msg) {
		super(msg);
	}
}
