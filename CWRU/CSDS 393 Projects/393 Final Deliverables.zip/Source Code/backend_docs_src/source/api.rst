API Documentation
============================


URLS
-----------
Testing API: ``https://api.bill.codetector.org``


So for example: /auth/auth you would send the ``POST`` request to ``https://api.bill.codetector.org/auth/auth``

/auth/
------------

`/auth </api/auth.html>`_


.. toctree::
   :hidden:
   :glob:

   api/auth.rst
