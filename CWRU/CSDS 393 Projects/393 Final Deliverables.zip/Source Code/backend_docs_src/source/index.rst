Bill Splitting System Documentation
======================================


.. toctree::
   :hidden:
   :glob:

   api
..
   Indices and tables
   ==================
   * :ref:`genindex`
   * :ref:`modindex`
   * :ref:`search`
